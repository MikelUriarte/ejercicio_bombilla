

function encender() {
document.getElementById('bombilla').src = "imagenes/bombilla-on.gif";
}
function apagar(){
document.getElementById('bombilla').src = "imagenes/bombilla-off.gif";
}